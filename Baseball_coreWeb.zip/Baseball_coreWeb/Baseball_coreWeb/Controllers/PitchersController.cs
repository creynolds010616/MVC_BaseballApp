﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Baseball_coreWeb;

namespace Baseball_coreWeb.Controllers
{
    public class PitchersController : Controller
    {
        private readonly PitcherdbContext _context;

        public PitchersController(PitcherdbContext context)
        {
            _context = context;
        }

        // GET: Pitchers
        public async Task<IActionResult> Index()
        {
            return View(await _context.Pitchers.ToListAsync());
        }

        public IActionResult Top10Winners()
        {
            var top10winners = (from p in _context.Pitchers
                                orderby p.W descending
                                select p).Take(10);
            
            return View(top10winners);
        }

        public IActionResult Top10Saves()
        {
            var top10saves = (from p in _context.Pitchers
                                orderby p.Sv descending
                                select p).Take(10);

            return View(top10saves);
        }

        // GET: Pitchers/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pitcher = await _context.Pitchers
                .FirstOrDefaultAsync(m => m.Id == id);
            if (pitcher == null)
            {
                return NotFound();
            }

            return View(pitcher);
        }

        // GET: Pitchers/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Pitchers/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,PlayerName,Team,Age,G,Gs,Cg,Sho,Ip,H,Er,K,Bb,Hr,W,L,Sv,Bs,Hld,Era,Whip")] Pitcher pitcher)
        {
            if (ModelState.IsValid)
            {
                _context.Add(pitcher);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(pitcher);
        }

        // GET: Pitchers/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pitcher = await _context.Pitchers.FindAsync(id);
            if (pitcher == null)
            {
                return NotFound();
            }
            return View(pitcher);
        }

        // POST: Pitchers/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,PlayerName,Team,Age,G,Gs,Cg,Sho,Ip,H,Er,K,Bb,Hr,W,L,Sv,Bs,Hld,Era,Whip")] Pitcher pitcher)
        {
            if (id != pitcher.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(pitcher);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PitcherExists(pitcher.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(pitcher);
        }

        // GET: Pitchers/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pitcher = await _context.Pitchers
                .FirstOrDefaultAsync(m => m.Id == id);
            if (pitcher == null)
            {
                return NotFound();
            }

            return View(pitcher);
        }

        // POST: Pitchers/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var pitcher = await _context.Pitchers.FindAsync(id);
            _context.Pitchers.Remove(pitcher);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool PitcherExists(int id)
        {
            return _context.Pitchers.Any(e => e.Id == id);
        }
    }
}
